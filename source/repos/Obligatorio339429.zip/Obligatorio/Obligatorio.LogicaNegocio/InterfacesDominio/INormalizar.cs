﻿namespace Obligatorio.LogicaNegocio.InterfacesDominio
{
    public interface INormalizar
    {
        string Normalizar(string str);
    }
}
