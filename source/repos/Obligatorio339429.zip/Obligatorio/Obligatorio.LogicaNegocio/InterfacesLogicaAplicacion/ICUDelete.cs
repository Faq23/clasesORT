﻿namespace Obligatorio.LogicaNegocio.InterfacesLogicaAplicacion
{
    public interface ICUDelete<T>
    {
        void Execute(int id);
    }
}
