﻿namespace Obligatorio.LogicaNegocio.InterfacesLogicaAplicacion
{
    public interface ICUAdd<T>
    {
        void Execute(T obj);
    }
}
