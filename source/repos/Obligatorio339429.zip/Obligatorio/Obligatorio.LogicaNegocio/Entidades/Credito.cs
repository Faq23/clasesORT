﻿namespace Obligatorio.LogicaNegocio.Entidades
{
    public class Credito : MetodoPago
    {
        public Credito() : base() { }

        public override string ToString()
        {
            return "Credito";
        }
    }
}
