﻿using Microsoft.EntityFrameworkCore;

namespace Obligatorio.LogicaNegocio.Entidades
{
    [Owned]
    public abstract class MetodoPago
    {
        public MetodoPago() { }
    }
}
