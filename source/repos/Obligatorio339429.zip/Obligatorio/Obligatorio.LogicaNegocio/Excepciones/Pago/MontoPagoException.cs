﻿namespace Obligatorio.LogicaNegocio.Excepciones.Pago
{
    public class MontoPagoException : PagoException
    {
    }
}
