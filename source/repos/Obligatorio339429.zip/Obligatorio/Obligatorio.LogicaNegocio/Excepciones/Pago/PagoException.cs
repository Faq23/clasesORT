﻿namespace Obligatorio.LogicaNegocio.Excepciones.Pago
{
    public class PagoException : LogicaNegocioException
    {
    }
}
