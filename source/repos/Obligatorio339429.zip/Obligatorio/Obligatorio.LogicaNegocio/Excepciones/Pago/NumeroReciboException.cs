﻿namespace Obligatorio.LogicaNegocio.Excepciones.Pago
{
    public class NumeroReciboException : LogicaNegocioException
    {
    }
}
