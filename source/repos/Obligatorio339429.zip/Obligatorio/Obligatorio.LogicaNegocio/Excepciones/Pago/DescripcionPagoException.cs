﻿namespace Obligatorio.LogicaNegocio.Excepciones.Pago
{
    public class DescripcionPagoException : LogicaNegocioException
    {
    }
}
