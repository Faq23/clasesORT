﻿namespace Obligatorio.LogicaNegocio.Excepciones.Equipo
{
    public class EquipoException : LogicaNegocioException
    {
    }
}
