﻿namespace Obligatorio.LogicaNegocio.Excepciones.Equipo
{
    public class NombreEquipoException : LogicaNegocioException
    {
    }
}
