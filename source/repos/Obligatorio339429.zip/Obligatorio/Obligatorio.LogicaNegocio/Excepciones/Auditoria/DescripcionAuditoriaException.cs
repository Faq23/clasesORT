﻿namespace Obligatorio.LogicaNegocio.Excepciones.Auditoria
{
    public class DescripcionAuditoriaException : AuditoriaException
    {
    }
}
