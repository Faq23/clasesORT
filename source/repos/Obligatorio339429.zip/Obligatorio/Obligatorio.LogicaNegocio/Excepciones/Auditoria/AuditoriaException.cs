﻿namespace Obligatorio.LogicaNegocio.Excepciones.Auditoria
{
    public class AuditoriaException : LogicaNegocioException
    {
    }
}
