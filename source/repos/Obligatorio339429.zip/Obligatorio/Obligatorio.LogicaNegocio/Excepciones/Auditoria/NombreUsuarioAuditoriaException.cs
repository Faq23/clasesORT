﻿namespace Obligatorio.LogicaNegocio.Excepciones.Auditoria
{
    public class NombreUsuarioAuditoriaException : AuditoriaException
    {
    }
}
