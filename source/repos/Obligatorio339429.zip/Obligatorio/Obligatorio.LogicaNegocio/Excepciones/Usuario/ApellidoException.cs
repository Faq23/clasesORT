﻿namespace Obligatorio.LogicaNegocio.Excepciones.Usuario
{
    public class ApellidoException : LogicaNegocioException
    {
    }
}
