﻿namespace Obligatorio.LogicaNegocio.Excepciones.Usuario
{
    public class LoginException : LogicaNegocioException
    {
    }
}
