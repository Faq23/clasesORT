﻿namespace Obligatorio.LogicaNegocio.Excepciones.Usuario
{
    public class EmailException : LogicaNegocioException
    {
    }
}
