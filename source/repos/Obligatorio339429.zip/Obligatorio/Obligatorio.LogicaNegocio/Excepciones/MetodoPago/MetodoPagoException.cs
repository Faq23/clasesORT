﻿namespace Obligatorio.LogicaNegocio.Excepciones.MetodoPago
{
    public class MetodoPagoException : LogicaNegocioException
    {
    }
}
