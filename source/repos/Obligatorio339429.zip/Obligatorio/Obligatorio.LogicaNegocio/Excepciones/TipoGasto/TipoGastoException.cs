﻿namespace Obligatorio.LogicaNegocio.Excepciones.TipoGasto
{
    public class TipoGastoException : LogicaNegocioException
    {
    }
}
