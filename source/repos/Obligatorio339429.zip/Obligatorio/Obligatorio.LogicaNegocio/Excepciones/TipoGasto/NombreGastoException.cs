﻿namespace Obligatorio.LogicaNegocio.Excepciones.TipoGasto
{
    public class NombreGastoException : LogicaNegocioException
    {
    }
}
