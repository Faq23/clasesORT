﻿namespace Obligatorio.LogicaNegocio.Excepciones.TipoGasto
{
    public class DescripcionException : LogicaNegocioException
    {
    }
}
