﻿namespace Obligatorio.LogicaNegocio.InterfacesRepositorio
{
    public interface IRepositorioDelete<T>
    {
        void Delete(int ID);
    }
}
