﻿namespace Obligatorio.LogicaNegocio.InterfacesRepositorio
{
    public interface IRepositorioAdd<T>
    {
        void Add(T obj);
    }
}
