﻿namespace Obligatorio.LogicaAplicacion.dtos.Auditorias
{
    public record AuditoriaDTOAlta(string Descripcion, string EmailUsuario, DateTime FechaAccion)
    {
    }
}
