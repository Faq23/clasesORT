﻿namespace Obligatorio.LogicaAplicacion.dtos.Equipos
{
    public record EquipoDTOListado(int ID, string Nombre)
    {
    }
}
