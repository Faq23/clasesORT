﻿namespace Obligatorio.LogicaAplicacion.dtos.Equipos
{
    public record EquipoDTOAlta(string Nombre)
    {
    }
}
