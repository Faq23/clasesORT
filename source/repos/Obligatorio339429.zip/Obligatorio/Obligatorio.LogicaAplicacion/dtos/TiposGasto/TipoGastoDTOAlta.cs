﻿namespace Obligatorio.LogicaAplicacion.dtos.TiposGasto
{
    public record TipoGastoDTOAlta(string Nombre, string Descripcion)
    {
    }
}
