﻿namespace Obligatorio.LogicaAplicacion.dtos.TiposGasto
{
    public record TipoGastoDTOListado(int ID, string Nombre, string Descripcion)
    {
    }
}
