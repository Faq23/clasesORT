﻿using Obligatorio.LogicaAplicacion.dtos.Equipos;
using Obligatorio.LogicaAplicacion.Mapper;
using Obligatorio.LogicaNegocio.InterfacesLogicaAplicacion;
using Obligatorio.LogicaNegocio.InterfacesRepositorio;

namespace Obligatorio.LogicaAplicacion.CasosUso.Equipos
{
    public class AddEquipo : ICUAdd<EquipoDTOAlta>
    {
        private IRepositorioEquipo _repo;

        public AddEquipo(IRepositorioEquipo repo)
        {
            _repo = repo;
        }

        public void Execute(EquipoDTOAlta obj)
        {
            _repo.Add(EquipoMapper.FromDTO(obj));
        }
    }
}
